export type UserRole = 'user' | 'admin';

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string | null;
  photoURL: string | null;
  role: UserRole;
  createdAt: string;
  lastLogin: string;
}

export type MessageRole = 'user' | 'model';
export type MessageType = 'text' | 'image' | 'video' | 'code';

export interface ChatMessage {
  id?: string;
  userId: string;
  role: MessageRole;
  content: string;
  timestamp: any; // Firestore Timestamp
  type: MessageType;
}

export interface Generation {
  id?: string;
  userId: string;
  type: 'image' | 'video';
  prompt: string;
  url: string;
  timestamp: any; // Firestore Timestamp
}

export interface UsageMetric {
  date: string;
  chatCount: number;
  imageCount: number;
  videoCount: number;
  activeUsers: number;
}
