import React, { useState } from 'react';
import { 
  ImageIcon, 
  Video, 
  Search, 
  GraduationCap, 
  FileText, 
  Calendar, 
  Code, 
  FileSearch,
  Sparkles,
  Download,
  Copy,
  Check,
  RefreshCw,
  Loader2,
  MapPin
} from 'lucide-react';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';
import { geminiService } from '../services/gemini';
import { useAuth } from '../context/AuthContext';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase';

interface ToolProps {
  type: string;
}

export const ToolDashboard: React.FC<ToolProps> = ({ type }) => {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const { user } = useAuth();

  const handleAction = async () => {
    if (!input.trim() || loading || !user) return;
    setLoading(true);
    setOutput(null);

    try {
      let result;
      switch (type) {
        case 'image':
          result = await geminiService.generateImage(input);
          await addDoc(collection(db, 'generations'), {
            userId: user.uid,
            type: 'image',
            prompt: input,
            url: result,
            timestamp: serverTimestamp()
          });
          break;
        case 'video':
          const op = await geminiService.generateVideo(input);
          result = op; // In real app, poll for result
          break;
        case 'search':
          result = await geminiService.search(input);
          break;
        case 'homework':
          result = await geminiService.chat(`Explain this homework question step-by-step: ${input}`);
          break;
        case 'resume':
          result = await geminiService.chat(`Generate a professional resume based on these details: ${input}. Use a clean markdown format.`);
          break;
        case 'planner':
          result = await geminiService.chat(`Create a daily study schedule for these subjects and exam date: ${input}. Include breaks and focus areas.`);
          break;
        case 'code':
          result = await geminiService.chat(`Generate high-quality code for: ${input}. Include comments and best practices.`);
          break;
        case 'summarizer':
          result = await geminiService.chat(`Summarize the following text into key bullet points: ${input}`);
          break;
        default:
          break;
      }
      setOutput(result);
    } catch (error) {
      console.error('Tool error:', error);
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = () => {
    const text = typeof output === 'string' ? output : JSON.stringify(output);
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const renderOutput = () => {
    if (!output) return null;

    if (type === 'image') {
      return (
        <div className="space-y-4">
          <div className="aspect-square rounded-2xl overflow-hidden jarvis-border jarvis-glow">
            <img src={output} alt="Generated" className="w-full h-full object-cover" />
          </div>
          <button 
            onClick={() => {
              const link = document.createElement('a');
              link.href = output;
              link.download = `jarvis-gen-${Date.now()}.png`;
              link.click();
            }}
            className="w-full flex items-center justify-center gap-2 py-3 bg-jarvis-blue/20 text-jarvis-blue rounded-xl hover:bg-jarvis-blue/30 transition-colors"
          >
            <Download size={18} />
            Download Image
          </button>
        </div>
      );
    }

    if (type === 'search') {
      return (
        <div className="space-y-4">
          <div className="prose prose-invert prose-sm max-w-none jarvis-glass p-6 rounded-2xl border-white/10">
            <p>{output.text}</p>
            {output.sources.length > 0 && (
              <div className="mt-4 pt-4 border-t border-white/10">
                <p className="text-[10px] uppercase tracking-widest text-white/40 mb-2">Sources</p>
                <div className="flex flex-wrap gap-2">
                  {output.sources.map((source: any, i: number) => (
                    <a 
                      key={`${source.web?.uri || 'source'}-${i}`} 
                      href={source.web?.uri} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-[10px] bg-jarvis-blue/10 text-jarvis-blue px-2 py-1 rounded hover:bg-jarvis-blue/20 transition-colors"
                    >
                      {source.web?.title || 'Source'}
                    </a>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      );
    }

    return (
      <div className="relative group">
        <div className="prose prose-invert prose-sm max-w-none jarvis-glass p-6 rounded-2xl border-white/10 whitespace-pre-wrap font-mono">
          {output}
        </div>
        <button 
          onClick={copyToClipboard}
          className="absolute top-4 right-4 p-2 bg-white/10 rounded-lg hover:bg-white/20 transition-colors text-white/60"
        >
          {copied ? <Check size={16} className="text-emerald-400" /> : <Copy size={16} />}
        </button>
      </div>
    );
  };

  const getToolInfo = () => {
    switch (type) {
      case 'image': return { title: 'Image Generator', icon: ImageIcon, placeholder: 'Describe the image you want to create...' };
      case 'video': return { title: 'Video Generator', icon: Video, placeholder: 'Describe the video scene...' };
      case 'search': return { title: 'Web Search', icon: Search, placeholder: 'What information are you looking for?' };
      case 'homework': return { title: 'Homework Helper', icon: GraduationCap, placeholder: 'Paste your homework question here...' };
      case 'resume': return { title: 'Resume Builder', icon: FileText, placeholder: 'Enter your experience, skills, and education...' };
      case 'planner': return { title: 'Study Planner', icon: Calendar, placeholder: 'Enter subjects and exam date (e.g., Math, Science - June 15)...' };
      case 'code': return { title: 'Code Generator', icon: Code, placeholder: 'Describe the function or component you need...' };
      case 'summarizer': return { title: 'Notes Summarizer', icon: FileSearch, placeholder: 'Paste long text to summarize...' };
      default: return { title: 'AI Tool', icon: Sparkles, placeholder: 'Enter prompt...' };
    }
  };

  const info = getToolInfo();

  return (
    <div className="max-w-4xl mx-auto p-4 space-y-8">
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 rounded-xl bg-jarvis-blue/20 flex items-center justify-center jarvis-border jarvis-glow">
          <info.icon size={24} className="text-jarvis-blue" />
        </div>
        <div>
          <h2 className="text-2xl font-bold neon-text text-jarvis-blue">{info.title}</h2>
          <p className="text-xs text-white/40 uppercase tracking-widest">Advanced AI Subsystem</p>
        </div>
      </div>

      <div className="space-y-4">
        <div className="jarvis-glass rounded-2xl border border-white/10 p-4 focus-within:border-jarvis-blue/30 transition-colors">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={info.placeholder}
            className="w-full bg-transparent border-none focus:ring-0 text-sm py-2 px-2 resize-none min-h-[120px]"
          />
          <div className="flex justify-end mt-2">
            <button
              onClick={handleAction}
              disabled={!input.trim() || loading}
              className="flex items-center gap-2 px-6 py-2.5 bg-jarvis-blue text-jarvis-dark font-bold rounded-xl hover:scale-105 transition-all disabled:opacity-50 jarvis-glow"
            >
              {loading ? <Loader2 size={18} className="animate-spin" /> : <Sparkles size={18} />}
              {loading ? 'Processing...' : 'Execute'}
            </button>
          </div>
        </div>

        {output && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4"
          >
            <div className="flex items-center justify-between px-2">
              <p className="text-[10px] uppercase tracking-widest text-white/40">Generated Output</p>
              <button 
                onClick={() => setOutput(null)}
                className="text-[10px] uppercase tracking-widest text-jarvis-blue hover:underline"
              >
                Clear
              </button>
            </div>
            {renderOutput()}
          </motion.div>
        )}
      </div>

      {type === 'video' && (
        <div className="bg-jarvis-blue/5 border border-jarvis-blue/20 p-4 rounded-xl flex items-start gap-3">
          <div className="p-2 bg-jarvis-blue/20 rounded-lg text-jarvis-blue">
            <Video size={18} />
          </div>
          <div>
            <p className="text-xs font-bold text-jarvis-blue">Veo Video Generation</p>
            <p className="text-[10px] text-white/60 mt-1">
              Video generation can take up to 2 minutes. Jarvis will notify you once the rendering is complete.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
