import React, { useState } from 'react';
import { FileText, Download, Loader2, Plus, Trash2, Sparkles } from 'lucide-react';
import { motion } from 'motion/react';
import { geminiService } from '../services/gemini';

export const ResumeBuilder: React.FC = () => {
  const [details, setDetails] = useState({
    name: '',
    email: '',
    phone: '',
    summary: '',
    experience: [{ company: '', role: '', period: '', desc: '' }],
    education: [{ school: '', degree: '', year: '' }],
    skills: ''
  });
  const [isGenerating, setIsGenerating] = useState(false);
  const [resume, setResume] = useState<string | null>(null);

  const handleGenerate = async () => {
    setIsGenerating(true);
    try {
      const prompt = `Generate a professional resume based on these details: ${JSON.stringify(details)}. Format it beautifully in Markdown.`;
      const result = await geminiService.chat(prompt);
      setResume(result);
    } catch (error) {
      console.error('Resume error:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="h-full p-8 overflow-y-auto">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold jarvis-glow-text text-jarvis-cyan">Neural Resume Architect</h2>
          <p className="text-slate-500">Construct a high-impact professional profile using AI.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div className="jarvis-glass p-6 rounded-2xl border-white/5 space-y-4">
              <h3 className="text-sm font-bold uppercase tracking-widest text-jarvis-blue">Personal Information</h3>
              <input 
                placeholder="Full Name" 
                className="w-full bg-white/5 border border-white/10 rounded-lg p-3 text-sm"
                value={details.name}
                onChange={e => setDetails({...details, name: e.target.value})}
              />
              <div className="grid grid-cols-2 gap-4">
                <input 
                  placeholder="Email" 
                  className="bg-white/5 border border-white/10 rounded-lg p-3 text-sm"
                  value={details.email}
                  onChange={e => setDetails({...details, email: e.target.value})}
                />
                <input 
                  placeholder="Phone" 
                  className="bg-white/5 border border-white/10 rounded-lg p-3 text-sm"
                  value={details.phone}
                  onChange={e => setDetails({...details, phone: e.target.value})}
                />
              </div>
              <textarea 
                placeholder="Professional Summary" 
                className="w-full bg-white/5 border border-white/10 rounded-lg p-3 text-sm h-24 resize-none"
                value={details.summary}
                onChange={e => setDetails({...details, summary: e.target.value})}
              />
            </div>

            <button 
              onClick={handleGenerate}
              disabled={isGenerating}
              className="w-full jarvis-button py-4 flex items-center justify-center space-x-2"
            >
              {isGenerating ? <Loader2 className="w-5 h-5 animate-spin" /> : <><Sparkles className="w-5 h-5" /><span>Architect Resume</span></>}
            </button>
          </div>

          <div className="jarvis-glass p-6 rounded-2xl border-white/5 min-h-[500px]">
            {resume ? (
              <div className="prose prose-invert prose-sm max-w-none">
                <div className="flex justify-end mb-4">
                  <button className="p-2 bg-jarvis-cyan/10 text-jarvis-cyan rounded-lg border border-jarvis-cyan/30">
                    <Download className="w-4 h-4" />
                  </button>
                </div>
                <div className="bg-white/5 p-6 rounded-xl border border-white/10">
                  {resume}
                </div>
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center space-y-4 opacity-30">
                <FileText className="w-16 h-16" />
                <p className="text-sm uppercase tracking-widest">Preview Area</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
