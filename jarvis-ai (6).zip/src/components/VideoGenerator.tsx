import React, { useState, useEffect } from 'react';
import { Video, Download, Loader2, Sparkles, History, Upload, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { geminiService, getAI } from '../services/gemini';
import { cn } from '../lib/utils';
import { useAuth } from '../context/AuthContext';
import { db } from '../firebase';
import { collection, addDoc, query, where, orderBy, onSnapshot, serverTimestamp } from 'firebase/firestore';
import { Generation } from '../types';

export const VideoGenerator: React.FC = () => {
  const { user } = useAuth();
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [history, setHistory] = useState<Generation[]>([]);
  const [currentVideo, setCurrentVideo] = useState<string | null>(null);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [status, setStatus] = useState<string>('');
  const [engine, setEngine] = useState<'veo' | 'longcat'>('veo');
  const [hasApiKey, setHasApiKey] = useState<boolean>(true);

  useEffect(() => {
    const checkKey = async () => {
      if (window.aistudio?.hasSelectedApiKey) {
        const selected = await window.aistudio.hasSelectedApiKey();
        setHasApiKey(selected);
      }
    };
    checkKey();
  }, []);

  const handleSelectKey = async () => {
    if (window.aistudio?.openSelectKey) {
      await window.aistudio.openSelectKey();
      setHasApiKey(true);
    }
  };

  useEffect(() => {
    if (!user) return;

    const q = query(
      collection(db, 'generations'),
      where('userId', '==', user.uid),
      where('type', '==', 'video'),
      orderBy('timestamp', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const gens = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Generation[];
      setHistory(gens);
    });

    return () => unsubscribe();
  }, [user]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleGenerate = async () => {
    if (!prompt.trim() || isGenerating || !user) return;

    if (engine === 'veo' && !hasApiKey) {
      handleSelectKey();
      return;
    }

    setIsGenerating(true);
    setCurrentVideo(null);
    setStatus('Initializing Neural Engine...');

    try {
      let videoUrl = '';
      if (engine === 'veo') {
        let operation = await geminiService.generateVideo(prompt, selectedImage || undefined);
        
        // Poll for completion
        while (!operation.done) {
          setStatus('Synthesizing Temporal Frames...');
          await new Promise(resolve => setTimeout(resolve, 10000));
          operation = await getAI().operations.getVideosOperation({ operation });
        }
        
        const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
        if (downloadLink) {
          // Fetch the video with the API key
          const response = await fetch(downloadLink, {
            method: 'GET',
            headers: {
              'x-goog-api-key': process.env.GEMINI_API_KEY || '',
            },
          });
          const blob = await response.blob();
          videoUrl = URL.createObjectURL(blob);
        } else {
          throw new Error("Video generation failed: No download link");
        }
      } else {
        setStatus('Connecting to Long Cat API...');
        videoUrl = await geminiService.generateLongCatVideo(prompt);
      }
      
      setCurrentVideo(videoUrl);

      await addDoc(collection(db, 'generations'), {
        userId: user.uid,
        type: 'video',
        prompt: prompt.trim(),
        url: videoUrl,
        timestamp: serverTimestamp(),
        engine
      });
    } catch (error: any) {
      console.error('Video generation error:', error);
      if (error.message?.includes("Requested entity was not found")) {
        setHasApiKey(false);
        setStatus('Neural Link Reset - Please re-select key');
      } else {
        setStatus(`Neural Link Failed: ${error.message || 'Unknown Error'}`);
      }
    } finally {
      setIsGenerating(false);
      setStatus('');
    }
  };

  return (
    <div className="h-full flex flex-col p-6 space-y-8 overflow-y-auto">
      <div className="max-w-2xl mx-auto w-full space-y-6">
        <div className="text-center space-y-2">
          <h2 className="text-3xl font-bold jarvis-glow-text text-jarvis-cyan">Temporal Motion Synthesis</h2>
          <p className="text-slate-500">Animate your imagination with advanced AI video generation.</p>
        </div>

        <div className="jarvis-glass p-6 rounded-2xl border-jarvis-cyan/20 space-y-4">
          {!hasApiKey && engine === 'veo' && (
            <div className="p-4 bg-red-500/10 border border-red-500/30 rounded-xl flex items-center justify-between">
              <div className="flex items-center space-x-3 text-red-400">
                <X className="w-5 h-5" />
                <span className="text-xs font-bold uppercase tracking-widest">Neural Key Required</span>
              </div>
              <button 
                onClick={handleSelectKey}
                className="px-4 py-2 bg-red-500 text-white rounded-lg text-xs font-bold uppercase tracking-widest hover:bg-red-600 transition-colors"
              >
                Select Key
              </button>
            </div>
          )}

          <div className="flex items-center justify-center space-x-4 mb-4">
            <button 
              onClick={() => setEngine('veo')}
              className={cn(
                "px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-widest transition-all",
                engine === 'veo' ? "bg-jarvis-cyan text-jarvis-bg" : "bg-white/5 text-slate-500"
              )}
            >
              Veo Engine
            </button>
            <button 
              onClick={() => setEngine('longcat')}
              className={cn(
                "px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-widest transition-all",
                engine === 'longcat' ? "bg-jarvis-cyan text-jarvis-bg" : "bg-white/5 text-slate-500"
              )}
            >
              Long Cat API
            </button>
          </div>
          
          <div className="flex space-x-4">
            <div className="flex-1 space-y-4">
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Describe the scene you want to animate..."
                className="w-full h-32 bg-white/5 border border-white/10 rounded-xl p-4 focus:outline-none focus:border-jarvis-cyan/50 transition-colors text-slate-200 resize-none"
              />
            </div>
            
            <div className="w-32 h-32 shrink-0">
              <label className="relative w-full h-full flex flex-col items-center justify-center border-2 border-dashed border-white/10 rounded-xl hover:border-jarvis-cyan/50 transition-colors cursor-pointer group overflow-hidden">
                {selectedImage ? (
                  <>
                    <img src={selectedImage} alt="Reference" className="w-full h-full object-cover" />
                    <button 
                      onClick={(e) => { e.preventDefault(); setSelectedImage(null); }}
                      className="absolute top-1 right-1 p-1 bg-red-500 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </>
                ) : (
                  <>
                    <Upload className="w-6 h-6 text-slate-500 group-hover:text-jarvis-cyan" />
                    <span className="text-[10px] text-slate-500 mt-1 uppercase">Ref Image</span>
                  </>
                )}
                <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
              </label>
            </div>
          </div>

          <button
            onClick={handleGenerate}
            disabled={!prompt.trim() || isGenerating}
            className="w-full jarvis-button flex items-center justify-center space-x-2 py-4 disabled:opacity-50"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>{status}</span>
              </>
            ) : (
              <>
                <Video className="w-5 h-5" />
                <span>Initiate Temporal Sequence</span>
              </>
            )}
          </button>
        </div>

        <AnimatePresence>
          {currentVideo && (
            <motion.div
              key="current-video-preview"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="relative group rounded-2xl overflow-hidden border border-jarvis-cyan/30 shadow-[0_0_30px_rgba(0,242,255,0.1)]"
            >
              <video src={currentVideo} controls className="w-full h-auto" />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="space-y-4">
        <div className="flex items-center space-x-2 text-slate-400">
          <History className="w-5 h-5" />
          <h3 className="font-medium uppercase tracking-widest text-sm">Temporal Archive</h3>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {history.map((gen) => (
            <motion.div
              key={gen.id}
              className="jarvis-glass rounded-xl overflow-hidden border border-white/5 group"
            >
              <div className="aspect-video bg-black/40 flex items-center justify-center relative">
                <Video className="w-8 h-8 text-jarvis-blue/30" />
                <button 
                  onClick={() => setCurrentVideo(gen.url)}
                  className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40"
                >
                  <span className="px-4 py-2 bg-jarvis-cyan text-jarvis-bg rounded-lg font-bold text-xs uppercase tracking-widest">Replay</span>
                </button>
              </div>
              <div className="p-3">
                <p className="text-xs text-slate-400 truncate">{gen.prompt}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};
