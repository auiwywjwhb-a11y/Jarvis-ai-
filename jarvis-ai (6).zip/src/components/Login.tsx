import React, { useState } from 'react';
import { signInWithPopup, signInWithEmailAndPassword, createUserWithEmailAndPassword } from 'firebase/auth';
import { auth, googleProvider } from '../firebase';
import { LogIn, Mail, Lock, Chrome } from 'lucide-react';
import { motion } from 'motion/react';

export const Login: React.FC = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleGoogleLogin = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      if (isLogin) {
        await signInWithEmailAndPassword(auth, email, password);
      } else {
        await createUserWithEmailAndPassword(auth, email, password);
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 grid-bg">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md jarvis-glass p-8 rounded-2xl jarvis-border relative overflow-hidden"
      >
        <div className="scan-line" />
        
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-full border-2 border-jarvis-blue mx-auto mb-4 flex items-center justify-center jarvis-glow">
            <span className="text-jarvis-blue font-bold text-3xl">J</span>
          </div>
          <h1 className="text-3xl font-bold neon-text text-jarvis-blue mb-2 tracking-tight">JARVIS AI</h1>
          <p className="text-white/60">Authentication Required</p>
        </div>

        {error && (
          <div className="bg-red-500/10 border border-red-500/50 text-red-400 p-3 rounded-lg text-sm mb-6">
            {error}
          </div>
        )}

        <form onSubmit={handleEmailAuth} className="space-y-4">
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-white/40" size={18} />
            <input
              type="email"
              placeholder="Email Address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-lg py-2.5 pl-10 pr-4 focus:outline-none focus:border-jarvis-blue transition-colors"
              required
            />
          </div>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-white/40" size={18} />
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-lg py-2.5 pl-10 pr-4 focus:outline-none focus:border-jarvis-blue transition-colors"
              required
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-jarvis-blue text-jarvis-dark font-bold py-2.5 rounded-lg hover:bg-jarvis-blue/90 transition-all jarvis-glow flex items-center justify-center gap-2"
          >
            {loading ? 'Processing...' : (isLogin ? 'Initialize' : 'Register')}
            <LogIn size={18} />
          </button>
        </form>

        <div className="relative my-8">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-white/10"></div>
          </div>
          <div className="relative flex justify-center text-xs uppercase">
            <span className="bg-jarvis-dark px-2 text-white/40">Or connect via</span>
          </div>
        </div>

        <button
          onClick={handleGoogleLogin}
          className="w-full bg-white/5 border border-white/10 text-white py-2.5 rounded-lg hover:bg-white/10 transition-all flex items-center justify-center gap-3"
        >
          <Chrome size={18} />
          Google Account
        </button>

        <p className="text-center mt-8 text-sm text-white/40">
          {isLogin ? "Don't have access?" : "Already registered?"}{' '}
          <button 
            onClick={() => setIsLogin(!isLogin)}
            className="text-jarvis-blue hover:underline"
          >
            {isLogin ? 'Request Access' : 'Login'}
          </button>
        </p>
      </motion.div>
    </div>
  );
};
