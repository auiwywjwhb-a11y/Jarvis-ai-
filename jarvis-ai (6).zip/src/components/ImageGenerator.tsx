import React, { useState, useEffect } from 'react';
import { ImageIcon, Download, Loader2, Sparkles, History } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { geminiService } from '../services/gemini';
import { useAuth } from '../context/AuthContext';
import { db } from '../firebase';
import { collection, addDoc, query, where, orderBy, onSnapshot, serverTimestamp } from 'firebase/firestore';
import { Generation } from '../types';

export const ImageGenerator: React.FC = () => {
  const { user } = useAuth();
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [history, setHistory] = useState<Generation[]>([]);
  const [currentImage, setCurrentImage] = useState<string | null>(null);

  useEffect(() => {
    if (!user) return;
    const localHistory = JSON.parse(localStorage.getItem(`jarvis_gens_${user.uid}`) || '[]');
    setHistory(localHistory);
  }, [user]);

  const handleGenerate = async () => {
    if (!prompt.trim() || isGenerating || !user) return;

    setIsGenerating(true);
    setCurrentImage(null);

    try {
      const imageUrl = await geminiService.generateImage(prompt);
      setCurrentImage(imageUrl);

      // Save to local history (since Firestore has 1MB limit)
      const newGen: Generation = {
        id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        userId: user.uid,
        type: 'image',
        prompt: prompt.trim(),
        url: imageUrl,
        timestamp: new Date()
      };
      
      const localHistory = JSON.parse(localStorage.getItem(`jarvis_gens_${user.uid}`) || '[]');
      const updatedHistory = [newGen, ...localHistory].slice(0, 50); // Keep last 50
      localStorage.setItem(`jarvis_gens_${user.uid}`, JSON.stringify(updatedHistory));
      setHistory(updatedHistory);

      // Optional: Save metadata to Firestore without the large URL
      await addDoc(collection(db, 'generations_meta'), {
        userId: user.uid,
        type: 'image',
        prompt: prompt.trim(),
        timestamp: serverTimestamp()
      });
    } catch (error) {
      console.error('Generation error:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="h-full flex flex-col p-6 space-y-8 overflow-y-auto">
      <div className="max-w-2xl mx-auto w-full space-y-6">
        <div className="text-center space-y-2">
          <h2 className="text-3xl font-bold jarvis-glow-text text-jarvis-cyan">Neural Image Synthesis</h2>
          <p className="text-slate-500">Transform your thoughts into high-fidelity visual assets.</p>
        </div>

        <div className="jarvis-glass p-6 rounded-2xl border-jarvis-cyan/20 space-y-4">
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe the image you want to generate in detail..."
            className="w-full h-32 bg-white/5 border border-white/10 rounded-xl p-4 focus:outline-none focus:border-jarvis-cyan/50 transition-colors text-slate-200 resize-none"
          />
          <button
            onClick={handleGenerate}
            disabled={!prompt.trim() || isGenerating}
            className="w-full jarvis-button flex items-center justify-center space-x-2 py-4 disabled:opacity-50"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>Synthesizing...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5" />
                <span>Generate Visual Asset</span>
              </>
            )}
          </button>
        </div>

        <AnimatePresence>
          {currentImage && (
            <motion.div
              key="current-image-preview"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="relative group rounded-2xl overflow-hidden border border-jarvis-cyan/30 shadow-[0_0_30px_rgba(0,242,255,0.1)]"
            >
              <img src={currentImage} alt="Generated" className="w-full h-auto" />
              <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center space-x-4">
                <a 
                  href={currentImage} 
                  download="jarvis-gen.png"
                  className="p-3 bg-jarvis-cyan text-jarvis-bg rounded-full hover:scale-110 transition-transform"
                >
                  <Download className="w-6 h-6" />
                </a>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="space-y-4">
        <div className="flex items-center space-x-2 text-slate-400">
          <History className="w-5 h-5" />
          <h3 className="font-medium uppercase tracking-widest text-sm">Neural History</h3>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {history.map((gen) => (
            <motion.div
              key={gen.id}
              layoutId={gen.id}
              className="relative aspect-square rounded-xl overflow-hidden border border-white/5 group cursor-pointer"
              onClick={() => setCurrentImage(gen.url)}
            >
              <img src={gen.url} alt={gen.prompt} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity p-2 flex flex-col justify-end">
                <p className="text-[10px] text-white truncate">{gen.prompt}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};
