import React from 'react';
import { Settings, Menu, X } from 'lucide-react';
import { cn } from '../lib/utils';

interface HeaderProps {
  isMenuOpen: boolean;
  setIsMenuOpen: (open: boolean) => void;
}

export const Header: React.FC<HeaderProps> = ({ isMenuOpen, setIsMenuOpen }) => {
  return (
    <header className="lg:hidden fixed top-0 left-0 right-0 h-16 jarvis-glass border-b border-white/5 flex items-center justify-between px-4 z-50">
      <div className="w-10" /> {/* Spacer */}

      <div className="flex flex-col items-center">
        <h1 className="text-xl font-bold jarvis-glow-text text-jarvis-cyan tracking-widest leading-none">
          JARVIS
        </h1>
        <span className="text-[8px] text-jarvis-blue/60 uppercase tracking-[0.2em]">Neural Interface</span>
      </div>

      <button 
        onClick={() => setIsMenuOpen(!isMenuOpen)}
        className="p-2 text-slate-400 hover:text-jarvis-cyan transition-colors"
      >
        {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
      </button>
    </header>
  );
};
