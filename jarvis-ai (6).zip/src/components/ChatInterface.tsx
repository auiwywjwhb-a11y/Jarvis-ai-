import React, { useState, useEffect, useRef } from 'react';
import { Send, Bot, User, Loader2, Sparkles, Code, Terminal } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ReactMarkdown from 'react-markdown';
import { geminiService } from '../services/gemini';
import { useAuth } from '../context/AuthContext';
import { db } from '../firebase';
import { collection, addDoc, query, where, orderBy, onSnapshot, serverTimestamp } from 'firebase/firestore';
import { ChatMessage, MessageType } from '../types';
import { cn } from '../lib/utils';

interface ChatInterfaceProps {
  mode?: 'chat' | 'homework' | 'code' | 'summarize';
  systemPrompt?: string;
}

export const ChatInterface: React.FC<ChatInterfaceProps> = ({ mode = 'chat', systemPrompt }) => {
  const { user } = useAuth();
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!user) return;

    const q = query(
      collection(db, 'chats'),
      where('userId', '==', user.uid),
      orderBy('timestamp', 'asc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const msgs = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as ChatMessage[];
      setMessages(msgs);
    });

    return () => unsubscribe();
  }, [user]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() || isLoading || !user) return;

    const userMessage = input.trim();
    setInput('');
    setIsLoading(true);

    try {
      // Save user message to Firestore
      await addDoc(collection(db, 'chats'), {
        userId: user.uid,
        role: 'user',
        content: userMessage,
        timestamp: serverTimestamp(),
        type: mode === 'code' ? 'code' : 'text'
      });

      // Get history for context
      const history = messages.slice(-10).map(m => ({
        role: m.role,
        parts: [{ text: m.content }]
      }));

      let prompt = userMessage;
      if (mode === 'homework') prompt = `Explain this step-by-step: ${userMessage}`;
      if (mode === 'summarize') prompt = `Summarize this text concisely: ${userMessage}`;
      if (mode === 'code') prompt = `Generate or explain this code: ${userMessage}`;

      const response = await geminiService.chat(prompt, history);

      // Save AI response to Firestore
      await addDoc(collection(db, 'chats'), {
        userId: user.uid,
        role: 'model',
        content: response,
        timestamp: serverTimestamp(),
        type: mode === 'code' ? 'code' : 'text'
      });
    } catch (error) {
      console.error('Chat error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full max-w-4xl mx-auto">
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-6 space-y-6 scroll-smooth"
      >
        <AnimatePresence initial={false}>
          {messages.length === 0 && (
            <motion.div 
              key="chat-empty-state"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex flex-col items-center justify-center h-full text-center space-y-4"
            >
              <div className="w-16 h-16 rounded-full bg-jarvis-blue/10 flex items-center justify-center border border-jarvis-cyan/30 animate-pulse">
                <Bot className="w-8 h-8 text-jarvis-cyan" />
              </div>
              <h2 className="text-xl font-semibold text-slate-200">How can I assist you today?</h2>
              <p className="text-slate-500 max-w-sm">
                I am JARVIS, your advanced AI assistant. I can help with coding, homework, or general inquiries.
              </p>
            </motion.div>
          )}
          
          {messages.map((msg, idx) => (
            <motion.div
              key={msg.id || `msg-${idx}`}
              initial={{ opacity: 0, x: msg.role === 'user' ? 20 : -20 }}
              animate={{ opacity: 1, x: 0 }}
              className={cn(
                "flex items-start space-x-4",
                msg.role === 'user' ? "flex-row-reverse space-x-reverse" : "flex-row"
              )}
            >
              <div className={cn(
                "w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border",
                msg.role === 'user' 
                  ? "bg-jarvis-blue/20 border-jarvis-blue/50" 
                  : "bg-jarvis-cyan/10 border-jarvis-cyan/30"
              )}>
                {msg.role === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4 text-jarvis-cyan" />}
              </div>
              
              <div className={cn(
                "max-w-[80%] p-4 rounded-2xl jarvis-glass",
                msg.role === 'user' 
                  ? "rounded-tr-none border-jarvis-blue/20" 
                  : "rounded-tl-none border-jarvis-cyan/20"
              )}>
                <div className="prose prose-invert prose-sm max-w-none">
                  <ReactMarkdown>{msg.content}</ReactMarkdown>
                </div>
              </div>
            </motion.div>
          ))}
          
          {isLoading && (
            <motion.div
              key="chat-loading-state"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex items-start space-x-4"
            >
              <div className="w-8 h-8 rounded-lg bg-jarvis-cyan/10 border border-jarvis-cyan/30 flex items-center justify-center">
                <Loader2 className="w-4 h-4 text-jarvis-cyan animate-spin" />
              </div>
              <div className="p-4 rounded-2xl rounded-tl-none jarvis-glass border-jarvis-cyan/20">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-jarvis-cyan/50 rounded-full animate-bounce" />
                  <div className="w-2 h-2 bg-jarvis-cyan/50 rounded-full animate-bounce [animation-delay:0.2s]" />
                  <div className="w-2 h-2 bg-jarvis-cyan/50 rounded-full animate-bounce [animation-delay:0.4s]" />
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="p-6 border-t border-white/5">
        <form 
          onSubmit={handleSend}
          className="relative flex items-center"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={`Message JARVIS (${mode})...`}
            className="w-full bg-white/5 border border-white/10 rounded-xl px-6 py-4 pr-16 focus:outline-none focus:border-jarvis-cyan/50 transition-colors text-slate-200 placeholder:text-slate-600"
          />
          <button
            type="submit"
            disabled={!input.trim() || isLoading}
            className="absolute right-2 p-3 rounded-lg bg-jarvis-blue/20 text-jarvis-cyan hover:bg-jarvis-blue/30 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
          >
            <Send className="w-5 h-5" />
          </button>
        </form>
        <p className="text-[10px] text-center text-slate-600 mt-3 uppercase tracking-widest">
          Neural Link Active • System Version 4.0
        </p>
      </div>
    </div>
  );
};
