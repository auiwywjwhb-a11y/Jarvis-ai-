import React, { useState, useEffect } from 'react';
import { Users, BarChart3, Shield, Settings, Activity, Trash2, UserCheck, UserX } from 'lucide-react';
import { motion } from 'motion/react';
import { db } from '../firebase';
import { collection, query, getDocs, doc, updateDoc, deleteDoc, orderBy } from 'firebase/firestore';
import { UserProfile } from '../types';

export const AdminPanel: React.FC = () => {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [stats, setStats] = useState({
    totalUsers: 0,
    activeToday: 0,
    totalChats: 0,
    totalGens: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const usersSnap = await getDocs(collection(db, 'users'));
        const usersList = usersSnap.docs.map(doc => ({
          uid: doc.id,
          ...doc.data()
        } as UserProfile));
        setUsers(usersList);

        const chatsSnap = await getDocs(collection(db, 'chats'));
        const gensSnap = await getDocs(collection(db, 'generations'));

        setStats({
          totalUsers: usersList.length,
          activeToday: usersList.filter(u => {
            const lastLogin = new Date(u.lastLogin);
            const today = new Date();
            return lastLogin.toDateString() === today.toDateString();
          }).length,
          totalChats: chatsSnap.size,
          totalGens: gensSnap.size
        });
      } catch (error) {
        console.error('Admin fetch error:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const toggleUserRole = async (userId: string, currentRole: string) => {
    const newRole = currentRole === 'admin' ? 'user' : 'admin';
    try {
      await updateDoc(doc(db, 'users', userId), { role: newRole });
      setUsers(users.map(u => u.uid === userId ? { ...u, role: newRole as any } : u));
    } catch (error) {
      console.error('Role update error:', error);
    }
  };

  return (
    <div className="h-full p-8 space-y-8 overflow-y-auto">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold jarvis-glow-text text-jarvis-cyan">Central Command</h2>
        <div className="flex items-center space-x-2 text-xs uppercase tracking-widest text-slate-500">
          <Activity className="w-4 h-4 text-green-500" />
          <span>System Online</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {[
          { label: 'Total Users', value: stats.totalUsers, icon: Users, color: 'text-blue-400' },
          { label: 'Active Today', value: stats.activeToday, icon: Activity, color: 'text-green-400' },
          { label: 'Total Chats', value: stats.totalChats, icon: BarChart3, color: 'text-purple-400' },
          { label: 'Generations', value: stats.totalGens, icon: Shield, color: 'text-jarvis-cyan' },
        ].map((stat, i) => (
          <motion.div
            key={`stat-card-${stat.label}-${i}`}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="jarvis-glass p-6 rounded-2xl border-white/5"
          >
            <div className="flex items-center justify-between mb-4">
              <stat.icon className={cn("w-6 h-6", stat.color)} />
              <span className="text-xs font-bold text-slate-600 uppercase tracking-tighter">Live</span>
            </div>
            <p className="text-3xl font-bold text-slate-200">{stat.value}</p>
            <p className="text-xs text-slate-500 uppercase tracking-widest mt-1">{stat.label}</p>
          </motion.div>
        ))}
      </div>

      <div className="jarvis-glass rounded-2xl border-white/5 overflow-hidden">
        <div className="p-6 border-b border-white/5 flex items-center justify-between">
          <h3 className="font-bold uppercase tracking-widest text-sm">User Management</h3>
          <Settings className="w-4 h-4 text-slate-500" />
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-white/5 text-xs uppercase tracking-widest text-slate-500">
              <tr>
                <th className="px-6 py-4 font-medium">User</th>
                <th className="px-6 py-4 font-medium">Role</th>
                <th className="px-6 py-4 font-medium">Last Login</th>
                <th className="px-6 py-4 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {users.map((u) => (
                <tr key={u.uid} className="hover:bg-white/5 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center space-x-3">
                      <img src={u.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${u.uid}`} className="w-8 h-8 rounded-full" />
                      <div>
                        <p className="text-sm font-medium text-slate-200">{u.displayName || 'User'}</p>
                        <p className="text-xs text-slate-500">{u.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={cn(
                      "px-2 py-1 rounded-md text-[10px] font-bold uppercase tracking-widest",
                      u.role === 'admin' ? "bg-purple-500/20 text-purple-400 border border-purple-500/30" : "bg-blue-500/20 text-blue-400 border border-blue-500/30"
                    )}>
                      {u.role}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-xs text-slate-500">
                    {new Date(u.lastLogin).toLocaleString()}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center space-x-2">
                      <button 
                        onClick={() => toggleUserRole(u.uid, u.role)}
                        className="p-2 hover:bg-white/10 rounded-lg transition-colors text-slate-400 hover:text-jarvis-cyan"
                        title="Toggle Role"
                      >
                        {u.role === 'admin' ? <UserX className="w-4 h-4" /> : <UserCheck className="w-4 h-4" />}
                      </button>
                      <button className="p-2 hover:bg-white/10 rounded-lg transition-colors text-slate-400 hover:text-red-400">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(' ');
}
