import React from 'react';
import { 
  MessageSquare, 
  Image as ImageIcon, 
  Video, 
  Search, 
  GraduationCap, 
  FileText, 
  Calendar, 
  Mic, 
  Code, 
  FileSearch,
  Settings,
  LayoutDashboard,
  LogOut,
  X
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { auth } from '../firebase';
import { cn } from '../lib/utils';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isOpen?: boolean;
  onClose?: () => void;
}

const menuItems = [
  { id: 'chat', icon: MessageSquare, label: 'AI Chat' },
  { id: 'image', icon: ImageIcon, label: 'Image Gen' },
  { id: 'video', icon: Video, label: 'Video Gen' },
  { id: 'search', icon: Search, label: 'Web Search' },
  { id: 'homework', icon: GraduationCap, label: 'Homework' },
  { id: 'resume', icon: FileText, label: 'Resume' },
  { id: 'study', icon: Calendar, label: 'Study Plan' },
  { id: 'voice', icon: Mic, label: 'Voice' },
  { id: 'code', icon: Code, label: 'Code Gen' },
  { id: 'summarize', icon: FileSearch, label: 'Summarizer' },
];

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab, isOpen, onClose }) => {
  const { profile, isAdmin } = useAuth();

  const handleTabClick = (tabId: string) => {
    setActiveTab(tabId);
    if (onClose) onClose();
  };

  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      <aside className={cn(
        "fixed lg:static inset-y-0 left-0 w-64 h-screen jarvis-glass border-r border-white/5 flex flex-col z-50 transition-transform duration-300 lg:translate-x-0",
        isOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="p-6 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold jarvis-glow-text text-jarvis-cyan tracking-widest">
              JARVIS
            </h1>
            <p className="text-[10px] text-jarvis-blue/60 uppercase tracking-[0.3em] mt-1">
              Advanced Intelligence
            </p>
          </div>
          {onClose && (
            <button onClick={onClose} className="lg:hidden text-slate-400 hover:text-white">
              <X className="w-6 h-6" />
            </button>
          )}
        </div>

        <nav className="flex-1 overflow-y-auto px-4 space-y-2 py-4">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => handleTabClick(item.id)}
              className={cn(
                "w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-300 group",
                activeTab === item.id 
                  ? "bg-jarvis-blue/20 text-jarvis-cyan border border-jarvis-cyan/30 shadow-[0_0_15px_rgba(0,242,255,0.1)]" 
                  : "text-slate-400 hover:bg-white/5 hover:text-slate-200"
              )}
            >
              <item.icon className={cn(
                "w-5 h-5 transition-transform duration-300 group-hover:scale-110",
                activeTab === item.id ? "text-jarvis-cyan" : "text-slate-400"
              )} />
              <span className="text-sm font-medium">{item.label}</span>
            </button>
          ))}

          <button
            onClick={() => handleTabClick('admin')}
            className={cn(
              "w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-300 group",
              activeTab === 'admin' 
                ? "bg-jarvis-blue/20 text-jarvis-cyan border border-jarvis-cyan/30" 
                : "text-slate-400 hover:bg-white/5 hover:text-slate-200"
            )}
          >
            <Settings className="w-5 h-5" />
            <span className="text-sm font-medium">System Settings</span>
          </button>

          {isAdmin && (
            <button
              onClick={() => handleTabClick('admin')}
              className={cn(
                "w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-300 group mt-8",
                activeTab === 'admin' 
                  ? "bg-purple-500/20 text-purple-400 border border-purple-500/30" 
                  : "text-slate-400 hover:bg-white/5 hover:text-slate-200"
              )}
            >
              <LayoutDashboard className="w-5 h-5" />
              <span className="text-sm font-medium">Admin Panel</span>
            </button>
          )}
        </nav>

        <div className="p-4 border-t border-white/5 space-y-6">
          {profile && (
            <div className="relative group">
              {/* AI Profile UI */}
              <div className="absolute -inset-1 bg-gradient-to-r from-jarvis-cyan/20 to-jarvis-blue/20 rounded-xl blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"></div>
              <div className="relative flex items-center space-x-3 p-3 jarvis-glass rounded-xl border border-white/5">
                <div className="relative">
                  <div className="absolute inset-0 bg-jarvis-cyan/20 rounded-full animate-ping"></div>
                  <img 
                    src={profile.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${profile.uid}&backgroundColor=050505`} 
                    alt="AI Core" 
                    className="w-12 h-12 rounded-full border-2 border-jarvis-cyan/50 relative z-10 bg-jarvis-bg"
                  />
                  <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-jarvis-bg animate-pulse"></div>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-1">
                    <span className="w-2 h-2 bg-jarvis-cyan rounded-full animate-pulse"></span>
                    <p className="text-xs font-mono text-jarvis-cyan uppercase tracking-tighter">Authorized User</p>
                  </div>
                  <p className="text-sm font-bold text-slate-100 truncate font-mono">{profile.displayName || 'OPERATOR'}</p>
                  <p className="text-[10px] text-slate-500 truncate font-mono opacity-60">ID: {profile.uid.slice(0, 8)}...</p>
                </div>
              </div>
            </div>
          )}
          
          <button 
            onClick={() => auth.signOut()}
            className="w-full flex items-center justify-center space-x-2 px-4 py-3 text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-xl border border-white/5 transition-all duration-300 group"
          >
            <LogOut className="w-4 h-4 group-hover:rotate-12 transition-transform" />
            <span className="text-xs font-bold uppercase tracking-widest">Terminate Session</span>
          </button>
        </div>
      </aside>
    </>
  );
};
