import React, { useState } from 'react';
import { signInWithPopup, signInWithEmailAndPassword, createUserWithEmailAndPassword } from 'firebase/auth';
import { auth, googleProvider } from '../firebase';
import { motion } from 'motion/react';
import { Mail, Lock, Chrome, Loader2, Sparkles } from 'lucide-react';

export const Auth: React.FC = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleGoogleLogin = async () => {
    setLoading(true);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      if (isLogin) {
        await signInWithEmailAndPassword(auth, email, password);
      } else {
        await createUserWithEmailAndPassword(auth, email, password);
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-jarvis-bg relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-jarvis-blue/5 rounded-full blur-[120px] pointer-events-none" />
      <div className="scanline" />

      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md jarvis-glass p-8 rounded-3xl border-jarvis-cyan/20 relative z-10"
      >
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-jarvis-blue/10 rounded-2xl border border-jarvis-cyan/30 flex items-center justify-center mx-auto mb-4">
            <Sparkles className="w-8 h-8 text-jarvis-cyan" />
          </div>
          <h1 className="text-3xl font-bold jarvis-glow-text text-jarvis-cyan tracking-widest">JARVIS</h1>
          <p className="text-slate-500 mt-2 uppercase tracking-[0.2em] text-[10px]">Neural Interface v4.0</p>
        </div>

        <form onSubmit={handleEmailAuth} className="space-y-4">
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-500 uppercase tracking-widest ml-1">Email Address</label>
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-12 pr-4 focus:outline-none focus:border-jarvis-cyan/50 transition-colors text-slate-200"
                placeholder="name@example.com"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-500 uppercase tracking-widest ml-1">Password</label>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-12 pr-4 focus:outline-none focus:border-jarvis-cyan/50 transition-colors text-slate-200"
                placeholder="••••••••"
              />
            </div>
          </div>

          {error && <p className="text-xs text-red-400 text-center">{error}</p>}

          <button
            type="submit"
            disabled={loading}
            className="w-full jarvis-button py-3 mt-4 flex items-center justify-center space-x-2"
          >
            {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <span>{isLogin ? 'Initialize Link' : 'Create Neural Profile'}</span>}
          </button>
        </form>

        <div className="relative my-8">
          <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-white/5"></div></div>
          <div className="relative flex justify-center text-[10px] uppercase tracking-widest"><span className="bg-jarvis-bg px-4 text-slate-600">Or connect via</span></div>
        </div>

        <button
          onClick={handleGoogleLogin}
          disabled={loading}
          className="w-full flex items-center justify-center space-x-3 bg-white/5 border border-white/10 rounded-xl py-3 hover:bg-white/10 transition-colors text-slate-200"
        >
          <Chrome className="w-5 h-5" />
          <span className="text-sm font-medium">Google Authentication</span>
        </button>

        <p className="text-center mt-8 text-sm text-slate-500">
          {isLogin ? "Don't have a neural profile?" : "Already have a profile?"}{' '}
          <button
            onClick={() => setIsLogin(!isLogin)}
            className="text-jarvis-cyan hover:underline font-medium"
          >
            {isLogin ? 'Register' : 'Login'}
          </button>
        </p>
      </motion.div>
    </div>
  );
};
