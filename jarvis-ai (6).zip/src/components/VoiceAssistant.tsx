import React, { useState, useEffect, useRef } from 'react';
import { Mic, MicOff, Loader2, Volume2, VolumeX } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { geminiService } from '../services/gemini';

export const VoiceAssistant: React.FC = () => {
  const [isListening, setIsListening] = useState(false);
  const [isResponding, setIsResponding] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [response, setResponse] = useState('');
  const audioContextRef = useRef<AudioContext | null>(null);
  const sessionRef = useRef<any>(null);

  const startSession = async () => {
    try {
      setIsListening(true);
      // Implementation of Live API would go here
      // For demo, we simulate the interaction
      setTimeout(() => {
        setTranscript("Hello Jarvis, what's the status of the system?");
        setIsResponding(true);
        setTimeout(() => {
          setResponse("All systems are operational, sir. Neural links are stable and power levels are at 100%.");
          setIsResponding(false);
        }, 2000);
      }, 1500);
    } catch (error) {
      console.error('Voice error:', error);
      setIsListening(false);
    }
  };

  const stopSession = () => {
    setIsListening(false);
    setIsResponding(false);
    setTranscript('');
    setResponse('');
  };

  return (
    <div className="h-full flex flex-col items-center justify-center p-6 space-y-12">
      <div className="text-center space-y-4">
        <h2 className="text-4xl font-bold jarvis-glow-text text-jarvis-cyan tracking-widest uppercase">Neural Voice Link</h2>
        <p className="text-slate-500 max-w-md mx-auto">Direct cognitive interface with JARVIS. Speak clearly for optimal synthesis.</p>
      </div>

      <div className="relative flex items-center justify-center w-64 h-64">
        {/* Waveform Animation */}
        <div className="absolute inset-0 flex items-center justify-center space-x-1">
          {[...Array(20)].map((_, i) => (
            <motion.div
              key={`wave-bar-${i}`}
              animate={{
                height: isListening || isResponding ? [10, Math.random() * 100 + 20, 10] : 10,
                opacity: isListening || isResponding ? [0.3, 1, 0.3] : 0.2
              }}
              transition={{
                duration: 0.5,
                repeat: Infinity,
                delay: i * 0.05
              }}
              className="w-1 bg-jarvis-cyan rounded-full"
            />
          ))}
        </div>

        {/* Central Button */}
        <button
          onClick={isListening ? stopSession : startSession}
          className={cn(
            "relative z-10 w-32 h-32 rounded-full flex items-center justify-center transition-all duration-500",
            isListening 
              ? "bg-red-500/20 border-2 border-red-500 shadow-[0_0_30px_rgba(239,68,68,0.3)]" 
              : "bg-jarvis-blue/20 border-2 border-jarvis-cyan shadow-[0_0_30px_rgba(0,242,255,0.3)] hover:scale-110"
          )}
        >
          {isListening ? (
            <MicOff className="w-12 h-12 text-red-500" />
          ) : (
            <Mic className="w-12 h-12 text-jarvis-cyan" />
          )}
        </button>

        {/* Rotating Rings */}
        <motion.div 
          animate={{ rotate: 360 }}
          transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
          className="absolute inset-0 border border-jarvis-cyan/10 rounded-full"
        />
        <motion.div 
          animate={{ rotate: -360 }}
          transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
          className="absolute -inset-4 border border-jarvis-blue/5 rounded-full border-dashed"
        />
      </div>

      <div className="max-w-xl w-full space-y-6">
        <AnimatePresence>
          {transcript && (
            <motion.div
              key="voice-transcript"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="jarvis-glass p-4 rounded-xl border-jarvis-blue/20"
            >
              <div className="flex items-center space-x-2 text-xs text-slate-500 uppercase tracking-widest mb-2">
                <Mic className="w-3 h-3" />
                <span>User Input</span>
              </div>
              <p className="text-slate-200 italic">"{transcript}"</p>
            </motion.div>
          )}

          {response && (
            <motion.div
              key="voice-response"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="jarvis-glass p-4 rounded-xl border-jarvis-cyan/20"
            >
              <div className="flex items-center space-x-2 text-xs text-jarvis-cyan uppercase tracking-widest mb-2">
                <Volume2 className="w-3 h-3" />
                <span>Jarvis Response</span>
              </div>
              <p className="text-slate-200">{response}</p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(' ');
}
