import React, { useState } from 'react';
import { Search, Globe, ExternalLink, Loader2, Sparkles, ShieldCheck } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { geminiService } from '../services/gemini';
import ReactMarkdown from 'react-markdown';

export const WebSearch: React.FC = () => {
  const [query, setQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [result, setResult] = useState<{ text: string, sources: any[] } | null>(null);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim() || isSearching) return;

    setIsSearching(true);
    try {
      const data = await geminiService.search(query);
      setResult(data);
    } catch (error) {
      console.error('Search error:', error);
    } finally {
      setIsSearching(false);
    }
  };

  return (
    <div className="h-full p-8 overflow-y-auto">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="text-center space-y-2">
          <h2 className="text-3xl font-bold jarvis-glow-text text-jarvis-cyan">Global Intelligence Grid</h2>
          <p className="text-slate-500">Real-time data retrieval from the decentralized web.</p>
        </div>

        <form onSubmit={handleSearch} className="relative group">
          <div className="absolute inset-0 bg-jarvis-cyan/5 blur-xl rounded-2xl group-hover:bg-jarvis-cyan/10 transition-all" />
          <div className="relative flex items-center">
            <Search className="absolute left-6 w-6 h-6 text-jarvis-cyan/50" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Query the global network..."
              className="w-full bg-jarvis-card border border-white/10 rounded-2xl py-6 pl-16 pr-32 focus:outline-none focus:border-jarvis-cyan/50 text-xl text-slate-200"
            />
            <button
              type="submit"
              disabled={!query.trim() || isSearching}
              className="absolute right-4 jarvis-button py-3 px-8 disabled:opacity-50"
            >
              {isSearching ? <Loader2 className="w-5 h-5 animate-spin" /> : <span>Search</span>}
            </button>
          </div>
        </form>

        <AnimatePresence>
          {result && (
            <motion.div
              key="search-result-container"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              <div className="jarvis-glass p-8 rounded-2xl border-jarvis-cyan/20">
                <div className="flex items-center space-x-2 text-jarvis-cyan mb-4">
                  <ShieldCheck className="w-5 h-5" />
                  <span className="text-xs font-bold uppercase tracking-widest">Verified Intelligence</span>
                </div>
                <div className="prose prose-invert max-w-none">
                  <ReactMarkdown>{result.text}</ReactMarkdown>
                </div>
              </div>

              {result.sources.length > 0 && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {result.sources.map((source, i) => (
                    <a
                      key={`${source.web?.uri || 'source'}-${i}`}
                      href={source.web?.uri}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="jarvis-glass p-4 rounded-xl border-white/5 hover:border-jarvis-cyan/30 transition-all group"
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="p-2 bg-white/5 rounded-lg">
                            <Globe className="w-4 h-4 text-slate-400 group-hover:text-jarvis-cyan transition-colors" />
                          </div>
                          <div className="min-w-0">
                            <p className="text-sm font-medium text-slate-200 truncate">{source.web?.title || 'Source'}</p>
                            <p className="text-[10px] text-slate-500 truncate">{source.web?.uri}</p>
                          </div>
                        </div>
                        <ExternalLink className="w-4 h-4 text-slate-600 group-hover:text-jarvis-cyan" />
                      </div>
                    </a>
                  ))}
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};
