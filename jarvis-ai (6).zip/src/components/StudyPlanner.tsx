import React, { useState } from 'react';
import { Calendar, Clock, BookOpen, Loader2, Sparkles, CheckCircle2 } from 'lucide-react';
import { motion } from 'motion/react';
import { geminiService } from '../services/gemini';

export const StudyPlanner: React.FC = () => {
  const [examDate, setExamDate] = useState('');
  const [subjects, setSubjects] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [plan, setPlan] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!examDate || !subjects) return;
    setIsGenerating(true);
    try {
      const prompt = `Create a daily study schedule for an exam on ${examDate}. Subjects: ${subjects}. Include breaks and specific topics. Format as a clear schedule.`;
      const result = await geminiService.chat(prompt);
      setPlan(result);
    } catch (error) {
      console.error('Plan error:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="h-full p-8 overflow-y-auto">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold jarvis-glow-text text-jarvis-cyan">Cognitive Study Planner</h2>
          <p className="text-slate-500">Optimize your learning path with algorithmic scheduling.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="md:col-span-1 space-y-6">
            <div className="jarvis-glass p-6 rounded-2xl border-white/5 space-y-4">
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Exam Date</label>
                <input 
                  type="date" 
                  className="w-full bg-white/5 border border-white/10 rounded-lg p-3 text-sm text-slate-200"
                  value={examDate}
                  onChange={e => setExamDate(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Subjects</label>
                <textarea 
                  placeholder="e.g. Quantum Physics, Advanced Calculus, Neural Networks" 
                  className="w-full bg-white/5 border border-white/10 rounded-lg p-3 text-sm h-32 resize-none text-slate-200"
                  value={subjects}
                  onChange={e => setSubjects(e.target.value)}
                />
              </div>
              <button 
                onClick={handleGenerate}
                disabled={isGenerating || !examDate || !subjects}
                className="w-full jarvis-button py-4 flex items-center justify-center space-x-2"
              >
                {isGenerating ? <Loader2 className="w-5 h-5 animate-spin" /> : <><Sparkles className="w-5 h-5" /><span>Calculate Plan</span></>}
              </button>
            </div>
          </div>

          <div className="md:col-span-2">
            <div className="jarvis-glass p-8 rounded-2xl border-white/5 min-h-[400px]">
              {plan ? (
                <div className="prose prose-invert prose-sm max-w-none">
                  <div className="flex items-center space-x-2 text-jarvis-cyan mb-6">
                    <CheckCircle2 className="w-5 h-5" />
                    <span className="font-bold uppercase tracking-widest text-xs">Optimized Schedule Ready</span>
                  </div>
                  <div className="whitespace-pre-wrap text-slate-300 leading-relaxed">
                    {plan}
                  </div>
                </div>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-center space-y-4 opacity-30">
                  <Calendar className="w-16 h-16" />
                  <p className="text-sm uppercase tracking-widest">Awaiting Parameters</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
