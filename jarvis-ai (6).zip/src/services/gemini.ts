import { GoogleGenAI, Type, Modality, ThinkingLevel } from "@google/genai";

const getAI = () => {
  const apiKey = process.env.API_KEY || process.env.GEMINI_API_KEY || "";
  return new GoogleGenAI({ apiKey });
};

export { getAI };

declare global {
  interface Window {
    aistudio?: {
      hasSelectedApiKey: () => Promise<boolean>;
      openSelectKey: () => Promise<void>;
    };
  }
}

export const geminiService = {
  // 1. AI Chat Assistant
  async chat(message: string, history: { role: string; parts: { text: string }[] }[] = []) {
    const ai = getAI();
    const chat = ai.chats.create({
      model: "gemini-3-flash-preview",
      config: {
        systemInstruction: "You are Jarvis, a futuristic AI assistant inspired by Iron Man's Jarvis. You are helpful, sophisticated, and technically advanced. Use a professional yet slightly witty tone. You can help with coding, explanations, and general tasks.",
      }
    });

    const result = await chat.sendMessage({ message });
    return result.text;
  },

  // 2. Image Generator (Nano Banana)
  async generateImage(prompt: string) {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-image",
      contents: [{ parts: [{ text: prompt }] }],
      config: {
        imageConfig: {
          aspectRatio: "1:1",
        }
      }
    });

    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    throw new Error("No image generated");
  },

  // 3. Video Generator (Veo)
  async generateVideo(prompt: string, imageBase64?: string) {
    const ai = getAI();
    const payload: any = {
      model: 'veo-3.1-fast-generate-preview',
      prompt,
      config: {
        numberOfVideos: 1,
        resolution: '720p',
        aspectRatio: '16:9'
      }
    };

    if (imageBase64) {
      payload.image = {
        imageBytes: imageBase64.split(',')[1],
        mimeType: 'image/png'
      };
    }

    let operation = await ai.models.generateVideos(payload);
    return operation;
  },

  async getVideosOperation(operation: any) {
    const ai = getAI();
    return await ai.operations.getVideosOperation({ operation });
  },

  // 4. Real-Time Web Search
  async search(query: string) {
    const ai = getAI();
    try {
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: [{ parts: [{ text: query }] }],
        config: {
          tools: [{ googleSearch: {} }],
        },
      });
      return {
        text: response.text,
        sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
      };
    } catch (error) {
      console.error('Search error, falling back to basic chat:', error);
      const text = await this.chat(`Search for: ${query}`);
      return { text, sources: [] };
    }
  },

  // 5. Maps Grounding
  async searchPlaces(query: string, location?: { lat: number; lng: number }) {
    const ai = getAI();
    const config: any = {
      tools: [{ googleMaps: {} }],
    };

    if (location) {
      config.toolConfig = {
        retrievalConfig: {
          latLng: {
            latitude: location.lat,
            longitude: location.lng
          }
        }
      };
    }

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [{ parts: [{ text: query }] }],
      config,
    });

    return {
      text: response.text,
      sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
    };
  },

  // 6. Voice Assistant (Live API)
  connectLive(callbacks: any) {
    const ai = getAI();
    return ai.live.connect({
      model: "gemini-2.5-flash-native-audio-preview-09-2025",
      callbacks,
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: { prebuiltVoiceConfig: { voiceName: "Zephyr" } },
        },
        systemInstruction: "You are Jarvis. Respond concisely and helpfully via voice.",
      },
    });
  },

  // 7. Long Cat API Integration (Video Generation)
  async generateLongCatVideo(prompt: string) {
    const longCatApiKey = process.env.LONG_CAT_API_KEY;
    if (!longCatApiKey) {
      console.warn("LONG_CAT_API_KEY is not configured. Using mock fallback.");
      return "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4";
    }

    // Placeholder for real Long Cat API call
    try {
      const response = await fetch('https://api.longcat.example/v1/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${longCatApiKey}`
        },
        body: JSON.stringify({ prompt })
      });

      if (!response.ok) throw new Error('Long Cat API request failed');
      const data = await response.json();
      return data.videoUrl;
    } catch (error) {
      console.error('Long Cat API Error:', error);
      return "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4";
    }
  }
};
