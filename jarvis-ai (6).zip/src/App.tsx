import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Auth } from './components/Auth';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { ChatInterface } from './components/ChatInterface';
import { ImageGenerator } from './components/ImageGenerator';
import { VideoGenerator } from './components/VideoGenerator';
import { WebSearch } from './components/WebSearch';
import { VoiceAssistant } from './components/VoiceAssistant';
import { ResumeBuilder } from './components/ResumeBuilder';
import { StudyPlanner } from './components/StudyPlanner';
import { AdminPanel } from './components/AdminPanel';
import { Loader2, ShieldAlert } from 'lucide-react';

const AppContent: React.FC = () => {
  const { user, loading, profile, isAdmin } = useAuth();
  const [activeTab, setActiveTab] = useState('chat');
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  if (loading) {
    return (
      <div className="min-h-screen bg-jarvis-bg flex items-center justify-center">
        <div className="flex flex-col items-center space-y-4">
          <div className="relative">
            <Loader2 className="w-12 h-12 text-jarvis-cyan animate-spin" />
            <div className="absolute inset-0 blur-lg bg-jarvis-cyan/20 animate-pulse" />
          </div>
          <p className="text-jarvis-cyan text-xs uppercase tracking-[0.3em] animate-pulse">Initializing Neural Link...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <Auth />;
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'chat':
        return <ChatInterface />;
      case 'image':
        return <ImageGenerator />;
      case 'video':
        return <VideoGenerator />;
      case 'search':
        return <WebSearch />;
      case 'homework':
        return <ChatInterface mode="homework" />;
      case 'resume':
        return <ResumeBuilder />;
      case 'study':
        return <StudyPlanner />;
      case 'voice':
        return <VoiceAssistant />;
      case 'code':
        return <ChatInterface mode="code" />;
      case 'summarize':
        return <ChatInterface mode="summarize" />;
      case 'admin':
        return isAdmin ? <AdminPanel /> : (
          <div className="h-full flex flex-col items-center justify-center text-center space-y-4">
            <ShieldAlert className="w-16 h-16 text-red-500" />
            <h2 className="text-2xl font-bold text-slate-200">Access Denied</h2>
            <p className="text-slate-500">You do not have administrative clearance for this sector.</p>
          </div>
        );
      default:
        return <ChatInterface />;
    }
  };

  return (
    <div className="flex h-screen bg-jarvis-bg overflow-hidden relative">
      <div className="scanline" />
      
      <Header 
        isMenuOpen={isMenuOpen} 
        setIsMenuOpen={setIsMenuOpen} 
      />

      <Sidebar 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        isOpen={isMenuOpen} 
        onClose={() => setIsMenuOpen(false)} 
      />
      
      <main className="flex-1 relative overflow-hidden pt-16 lg:pt-0">
        {/* Background Ambient Glow */}
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-jarvis-blue/5 rounded-full blur-[100px] pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-[300px] h-[300px] bg-jarvis-cyan/5 rounded-full blur-[80px] pointer-events-none" />
        
        <div className="h-full relative z-10">
          {renderContent()}
        </div>
      </main>
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
